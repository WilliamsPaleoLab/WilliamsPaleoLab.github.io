This folder viewer32 contains the same functionality and images as Viewer 3_2.

The difference between the two versions of Pollen Viewer is that the viewer32 folder contains
files with lowercase file names.

The NGDC site put this requirement on Pollen Viewer. Call Jack Williams or John Keltner for more
information.

11/20/03
Phil Leduc